replaceitem entity @p[c=1] slot.hotbar 0 plane:gun 1 0
replaceitem entity @p[c=1] slot.hotbar 1 plane:parachutes 1 0
