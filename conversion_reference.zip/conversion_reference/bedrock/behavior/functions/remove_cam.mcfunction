tag @s remove cam
camera @s clear
camera @s set minecraft:first_person