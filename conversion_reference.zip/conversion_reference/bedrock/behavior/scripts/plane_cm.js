//Credit to Moriarty for the script!
import {
    Player,
    world,
    system
} from "@minecraft/server";

world.afterEvents.itemUse.subscribe((data) => {

 const player = data.source;
 const item = data.itemStack;
 const itemCD = item.getComponent("minecraft:cooldown");
 const cooldown = itemCD?.getCooldownTicksRemaining(player);

 if (cooldown >= 0.1) {
    return;
}

 switch (item.typeId) {
 case 
 'plane:parachutes':
    player.runCommand("summon plane:parachute ~~~~~ minecraft:eject");
    player.runCommand("event entity @e[type=plane:shinden,c=1] minecraft:default");
    player.runCommand("playanimation @e[type=plane:shinden,c=1] animation.shinden_plane.fall");
    player.runCommand("clear plane:parachutes");
    player.runCommand("clear plane:cam");
    player.runCommand("clear plane:cam_clear");
    player.runCommand("function remove_cam");
    player.runCommand("effect @e[type=plane:parachute,c=1] levitation 2 40 true");
    itemCD.startCooldown(player);
      break;
      
 case 
 'plane:gun':
      player.runCommand("event entity @e[type=plane:shinden,c=1] minecraft:firing");
      player.runCommand("playanimation @e[type=plane:shinden,c=1] animation.shinden_plane.firing");
      player.runCommand("playsound shinden_fire @p[rm=55] ~~~ 15");
      player.runCommand("playsound shinden_fire @p[r=55] ~~~ 15");
      itemCD.startCooldown(player);
      break;
      
 case 
 'plane:cam':
      player.runCommand(
        "tag @s add cam");
      player.runCommand(           
        "replaceitem entity @s slot.hotbar 2 plane:cam_clear");
      itemCD.startCooldown(player);
      break;
      
 case 
 'plane:cam_clear':
      player.runCommand
      (
        "tag @s remove cam");
      player.runCommand(           
        "replaceitem entity @s slot.hotbar 2 plane:cam");
      player.runCommand(            
        "camera @s clear" );
      player.runCommand(           
       "camera @s set minecraft:first_person" );
      itemCD.startCooldown(player);
      break;
      
     
 // add more items ids if you want 
    }
});